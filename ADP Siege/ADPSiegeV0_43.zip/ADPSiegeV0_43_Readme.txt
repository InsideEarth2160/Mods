ADP Siege V0.43

ADP Siege is a mod for Earth 2160. V0.43 contains quite a lot of new stuff, and this is the first public release for most of the material.

Note: Previous versions of this mod meant you could only play multiplayer against players who also had the mod. This is no longer the case.

When you select the "ADP Siege" gametype to play, it uses a number of projects:
-ADP: Adds normal buildings, modular construction, research, new particle effects and sounds to the Alien race. This version doesn't have new models yet.
-Siege: This is a new gametype in which you gain money by capturing Mines (with soldiers) instead of collecting resources and win by capturing Objective buildings instead of destroying enemy Structures. Apart from that, it works like the normal game.
-EScripts V0.7: There are three new unit scripts. Scripts change the behaviour of tanks, infantry and units - there are a few important fixes and some new useful features.
-SuperStorm V3.1: This has a few new features from V3.0, including Virtual Agents.

Automatic install:
Rather than downloading and installing manually, you can use the EarthCP program from Inside Earth to automatically download, update and install mods for you.

To manually install:
Locate your main Earth 2160 folder, and place the WD file in there (I suggest the WDFiles folder).

To manually remove:
Delete the WD file, or move it completely out of your Earth 2160 directory.

For more info (including version changes):
See www.forcesofchaos.com/Horizon/ADP.php

Credits:
-FoC-D
Main project work: SpaceTug
Siege maps, testing support: Dragon Fly
Maps, sounds, tech icons: Chip
Modelling (in-progress): Simon
-Community
Translations: Arks, ex-deus, Slavich2150, mensi, CABAListic, Rosic, Medivh.